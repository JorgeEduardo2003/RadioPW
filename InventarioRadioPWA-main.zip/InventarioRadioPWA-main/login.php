<?php
include "conexion.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];
    $rol = $_POST['roles']; // Capturamos el rol seleccionado

    //segun rol
    //$tabla = ($rol == "administrador") ? "loginadmin" : "loginusers";
    //$campoUsuario = ($rol == "administrador") ? "usuario" : "user";

    $sql = "SELECT contra FROM users WHERE user = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $usuario);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($contra);
        $stmt->fetch();

        if (password_verify($password, $contra)) {
            session_start();
            $_SESSION['usuario'] = $usuario;
            $_SESSION['rol'] = $rol; // rol del user
            header("Location: dashboard.php");
            exit();
        } else {
            echo "<script type='text/javascript'>alert('Contraseña Incorrecta');</script>";
        }
    } else {
        echo "<script type='text/javascript'>alert('Usuario no encontrado');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>
