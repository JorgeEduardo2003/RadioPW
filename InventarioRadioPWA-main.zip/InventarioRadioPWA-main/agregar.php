<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sql = "INSERT INTO inventariofull (ID, Clasificacion, Descripcion, Valor, Resguardante, `Ubicacion/Lote`, Marca, Modelo, Serie, Origen, Estatus, Vinculado, Tipo) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssssssss", $_POST["ID"], $_POST["Clasificacion"], $_POST["Descripcion"], $_POST["Valor"], $_POST["Resguardante"], $_POST["Ubicacion/Lote"], $_POST["Marca"], $_POST["Modelo"], $_POST["Serie"], $_POST["Origen"], $_POST["Estatus"], $_POST["Vinculado"], $_POST["Tipo"]);

    if ($stmt->execute()) {
        echo "<script>alert('Producto agregado correctamente'); window.location.href='index.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
