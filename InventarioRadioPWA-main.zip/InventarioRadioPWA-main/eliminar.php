<?php
include 'conexion.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM inventariofull WHERE ID = '$id'";

    if ($conn->query($sql) === TRUE) {
        //echo "Producto eliminado correctamente";
        header("Location: index.php?mensaje=eliminado");
        exit();
    } else {
        echo "Error al eliminar el producto: " . $conn->error;
    }
}

$conn->close();
?>


