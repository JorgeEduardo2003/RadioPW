<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventario</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

    .btn-pdf {
        background-color: #007bff;
    }

    .btn-pdf:hover {
    background-color: #0056b3;
    }

        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 0;
            background-color: #000000;
            color: #ffffff;
        }

        h1 {
            text-align: center;
            color: #FFD700;
        }

        .search-container {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        input[type="search"] {
            width: 60%;
            padding: 10px;
            border: 2px solid #FFD700;
            border-radius: 5px;
            background-color: #333333;
            color: white;
        }

        .btn-custom {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            color: white;
        }

        .btn-add {
            background-color: #28a745;
        }

        .btn-delete {
            background-color: #dc3545;
        }

        .btn-add:hover {
            background-color: #218838;
        }

        .btn-delete:hover {
            background-color: #c82333;
        }

        .table-container {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            /* margin: 20px 0; */
            background-color: #000000;
            color: #ffffff;
        }

        th,
        td {
            padding: 12px 15px;
            text-align: left;
            border: 1px solid #444444;
        }

        th {
            background-color: #D32F2F;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #333333;
        }

        tr:hover {
            background-color: #B71C1C;
            color: white;
        }
        
    </style>

    <script>
        function buscarProducto() {
            let input = document.getElementById("buscar").value;
            let xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("tabla-body").innerHTML = this.responseText;
                }
            };
            xhr.open("GET", "buscar.php?q=" + input, true);
            xhr.send();
        }
    </script>
    <script>
        function openModal(fila) {
            document.getElementById("modal-id").innerText = fila.cells[0].innerText;
            document.getElementById("modal-clasificacion").innerText = fila.cells[1].innerText;
            document.getElementById("modal-descripcion").innerText = fila.cells[2].innerText;
            document.getElementById("modal-valor").innerText = fila.cells[3].innerText;
            document.getElementById("modal-resguardante").innerText = fila.cells[4].innerText;
            document.getElementById("modal-ubicacion").innerText = fila.cells[5].innerText;
            document.getElementById("modal-marca").innerText = fila.cells[6].innerText;
            document.getElementById("modal-modelo").innerText = fila.cells[7].innerText;
            document.getElementById("modal-serie").innerText = fila.cells[8].innerText;
            document.getElementById("modal-origen").innerText = fila.cells[9].innerText;
            document.getElementById("modal-estatus").innerText = fila.cells[10].innerText;
            document.getElementById("modal-vinculado").innerText = fila.cells[11].innerText;
            document.getElementById("modal-tipo").innerText = fila.cells[12].innerText;

            // document.getElementById("modalInf").style.display = "block";
            var modalElement = document.getElementById('modalInf');
            var modal = new bootstrap.Modal(modalElement);
            modal.show();
        }
        
    </script>
    <script>
        function cerrarModInfo(){
            document.getElementById("modalInf").style.display = "none";
        }
    </script>
</head>

<body>
    <h1>Inventario</h1>

    <div class="search-container mt-3">
        <input type="search" id="buscar" placeholder="Buscar" onkeyup="buscarProducto()">
        <button class="btn-custom btn-add" data-bs-toggle="modal" data-bs-target="#modalAgregar">Agregar Producto</button>
        
        <!-- <button class="btn-custom btn-delete">Eliminar</button> -->
    </div>
    

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Clasificación</th>
                <th>Descripción</th>
                <th>Valor</th>
                <th>Resguardante</th>
                <th>Ubicación/Lote</th>
                <th>Marca</th>
                <th>Modelo</th>
                <th>Serie</th>
                <th>Origen</th>
                <th>Estatus</th>
                <th>Vinculado</th>
                <th>Tipo</th>
            </tr>
        </thead>
        <tbody id="tabla-body">
            <?php
            include 'conexion.php';
            $sql = "SELECT * FROM inventariofull";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr onclick='openModal(this); seleccionarFila(this, {$row['ID']});'>";
                    echo "<td>{$row['ID']}</td>";
                    echo "<td>{$row['Clasificacion']}</td>";
                    echo "<td>{$row['Descripcion']}</td>";
                    echo "<td>$"."{$row['Valor']}</td>"; //signo de dinero primero
                    echo "<td>{$row['Resguardante']}</td>";
                    echo "<td>{$row['Ubicacion/Lote']}</td>";
                    echo "<td>{$row['Marca']}</td>";
                    echo "<td>{$row['Modelo']}</td>";
                    echo "<td>{$row['Serie']}</td>";
                    echo "<td>{$row['Origen']}</td>";
                    echo "<td>{$row['Estatus']}</td>";
                    echo "<td>{$row['Vinculado']}</td>";
                    echo "<td>{$row['Tipo']}</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='13'>No hay resultados</td></tr>";
            }
            $conn->close();
            ?>
        </tbody>
    </table>

    <!-- Modal de Agregar -->
    <div class="modal fade" id="modalAgregar" tabindex="-1" aria-labelledby="modalAgregarLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content text-dark">
                <div class="modal-header">
                    <h5 class="modal-title">Agregar Producto</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form action="agregar.php" method="POST">
                        <div class="row">
                            <?php
                            $campos = ["ID", "Clasificacion", "Descripcion", "Valor", "Resguardante", "Ubicacion/Lote", "Marca", "Modelo", "Serie", "Origen", "Estatus", "Vinculado", "Tipo"];
                            foreach ($campos as $campo) {
                                echo '<div class="col-md-6 mb-3">';
                                echo "<label>$campo</label>";
                                echo "<input type='text' class='form-control' name='$campo' required>";
                                echo "</div>";
                            }
                            ?>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            <button type="submit" class="btn btn-success">Guardar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


<!-- Modal Info-->
<div class="modal fade" id="modalInf" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg"> <!-- modal-lg para hacerlo más grande -->
        <div class="modal-content">
            <div class="modal-header">
            
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <h3 style="color: black; text-align: center;">Detalles del Producto</h3>
                <table>
                <tr><th>ID</th><td id="modal-id"></td></tr>
                <tr><th>Clasificación</th><td id="modal-clasificacion"></td></tr>
                <tr><th>Descripción</th><td id="modal-descripcion"></td></tr>
                <tr><th>Valor</th><td id="modal-valor"></td></tr>
                <tr><th>Resguardante</th><td id="modal-resguardante"></td></tr>
                <tr><th>Ubicación/Lote</th><td id="modal-ubicacion"></td></tr>
                <tr><th>Marca</th><td id="modal-marca"></td></tr>
                <tr><th>Modelo</th><td id="modal-modelo"></td></tr>
                <tr><th>Serie</th><td id="modal-serie"></td></tr>
                <tr><th>Origen</th><td id="modal-origen"></td></tr>
                <tr><th>Estatus</th><td id="modal-estatus"></td></tr>
                <tr><th>Vinculado</th><td id="modal-vinculado"></td></tr>
                <tr><th>Tipo</th><td id="modal-tipo"></td></tr>
            </table>
            </div>
            <div class="modal-footer d-flex justify-content-center">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal" onclick="eliminarProducto()">Eliminar</button>
                <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Editar</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" >Cerrar</button>
                <button class="btn-custom btn-pdf" onclick="generarPDF()">Generar PDF</button>
            </div>
        </div>
    </div>
</div>


<script>
    let idSeleccionado = null;
    function generarPDF() {
    if (idSeleccionado) {
        window.location.href = 'generarpdf.php?id=' + idSeleccionado;
    } else {
        alert('Por favor, seleccione un producto antes de generar el PDF.');
    }
}
function seleccionarFila(fila, id) {
    idSeleccionado = id; // Guardar el ID seleccionado en una variable
    document.getElementById("modal-id").value = id; // Guardar en el input oculto
    console.log("ID seleccionado: " + idSeleccionado); // Para depuración
}

function eliminarProducto() {
    if (idSeleccionado) {
        if (confirm("¿Estás seguro de eliminar este producto?")) {
            window.location.href = "eliminar.php?id=" + idSeleccionado; // Redirigir a eliminar.php con el ID
        }
    } else {
        alert("Selecciona un producto antes de eliminar.");
    }
}
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<?php
    if (isset($_GET['mensaje'])) {
        if ($_GET['mensaje'] == "eliminado") {
            echo "<div class='alert alert-success'>Producto eliminado correctamente.</div>";
            
        }
    }
    ?>
</body>

</html>
