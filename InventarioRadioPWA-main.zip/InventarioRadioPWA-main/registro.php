<?php
include "conexion.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['new-user'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $password = password_hash($_POST['new-password'], PASSWORD_BCRYPT); // Hashear la contraseña
    $rol = $_POST['roles']; // rol

    //segun rol
    $rolAsignado = ($rol == "administrador") ? "administrador" : "usuario"; 

    $sql = "INSERT INTO users (user, contra, nombre, apellido, tipo) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    
    $stmt->bind_param("sssss", $usuario, $password, $nombre, $apellido, $rolAsignado);

    if ($stmt->execute()) {
        header("Location: login.html?registro=exitoso"); 
        exit();
    } else {
        echo "Error al registrar: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>

