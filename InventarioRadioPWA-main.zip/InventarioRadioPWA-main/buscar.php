<?php
include 'conexion.php';

$q = isset($_GET['q']) ? $_GET['q'] : '';

$sql = "SELECT * FROM inventariofull WHERE ID LIKE '%$q%' OR Clasificacion LIKE '%$q%' OR Descripcion LIKE '%$q%' OR Valor LIKE '%$q%' OR Resguardante LIKE '%$q%' OR Marca LIKE '%$q%' OR Modelo LIKE '%$q%' OR Tipo LIKE '%$q%'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // echo "<tr>";
        // echo "<td>" . $row['ID'] . "</td>";
        // echo "<td>" . $row['Clasificacion'] . "</td>";
        // echo "<td>" . $row['Descripcion'] . "</td>";
        // echo "<td>" . $row['Resguardante'] . "</td>";
        // echo "<td>" . $row['Ubicacion/Lote'] . "</td>";
        // echo "<td>" . $row['Marca'] . "</td>";
        // echo "<td>" . $row['Modelo'] . "</td>";
        // echo "<td>" . $row['Serie'] . "</td>";
        // echo "<td>" . $row['Origen'] . "</td>";
        // echo "<td>" . $row['Estatus'] . "</td>";
        // echo "<td>" . $row['Tipo'] . "</td>";
        // echo "</tr>";
                    echo "<td>{$row['ID']}</td>";
                    //echo "<tr onclick='openModal(this)'>";
                    echo "<td>{$row['Clasificacion']}</td>";
                    echo "<td>{$row['Descripcion']}</td>";
                    echo "<td>$"."{$row['Valor']}</td>";
                    echo "<td>{$row['Resguardante']}</td>";
                    echo "<td>{$row['Ubicacion/Lote']}</td>";
                    echo "<td>{$row['Marca']}</td>";
                    echo "<td>{$row['Modelo']}</td>";
                    echo "<td>{$row['Serie']}</td>";
                    echo "<td>{$row['Origen']}</td>";
                    echo "<td>{$row['Estatus']}</td>";
                    echo "<td>{$row['Vinculado']}</td>";
                    echo "<td>{$row['Tipo']}</td>";
                    echo "</tr>";
    }
} else {
    echo "<tr><td colspan='11'>No hay resultados</td></tr>";
}

$conn->close();
?>

<!-- <div class="modal fade" id="modalInf" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg"> 
        <div class="modal-content">
            <div class="modal-header">
            
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
            <h3 style="color: black; text-align: center;">Detalles del Producto</h3>
                <table>
                <tr><th>ID</th><td id="modal-id"></td></tr>
                <tr><th>Clasificación</th><td id="modal-clasificacion"></td></tr>
                <tr><th>Descripción</th><td id="modal-descripcion"></td></tr>
                <tr><th>Valor</th><td id="modal-valor"></td></tr>
                <tr><th>Resguardante</th><td id="modal-resguardante"></td></tr>
                <tr><th>Ubicación/Lote</th><td id="modal-ubicacion"></td></tr>
                <tr><th>Marca</th><td id="modal-marca"></td></tr>
                <tr><th>Modelo</th><td id="modal-modelo"></td></tr>
                <tr><th>Serie</th><td id="modal-serie"></td></tr>
                <tr><th>Origen</th><td id="modal-origen"></td></tr>
                <tr><th>Estatus</th><td id="modal-estatus"></td></tr>
                <tr><th>Vinculado</th><td id="modal-vinculado"></td></tr>
                <tr><th>Tipo</th><td id="modal-tipo"></td></tr>
            </table>
            </div>
            <div class="modal-footer d-flex justify-content-center">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Eliminar</button>
                <button type="button" class="btn btn-warning" data-bs-dismiss="modal">Editar</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" >Cerrar</button>
            </div>
        </div>
    </div>
</div>  -->
<!-- <script>
        function openModal(fila) {
            document.getElementById("modal-id").innerText = fila.cells[0].innerText;
            document.getElementById("modal-clasificacion").innerText = fila.cells[1].innerText;
            document.getElementById("modal-descripcion").innerText = fila.cells[2].innerText;
            document.getElementById("modal-valor").innerText = fila.cells[3].innerText;
            document.getElementById("modal-resguardante").innerText = fila.cells[4].innerText;
            document.getElementById("modal-ubicacion").innerText = fila.cells[5].innerText;
            document.getElementById("modal-marca").innerText = fila.cells[6].innerText;
            document.getElementById("modal-modelo").innerText = fila.cells[7].innerText;
            document.getElementById("modal-serie").innerText = fila.cells[8].innerText;
            document.getElementById("modal-origen").innerText = fila.cells[9].innerText;
            document.getElementById("modal-estatus").innerText = fila.cells[10].innerText;
            document.getElementById("modal-vinculado").innerText = fila.cells[11].innerText;
            document.getElementById("modal-tipo").innerText = fila.cells[12].innerText;

            // document.getElementById("modalInf").style.display = "block";
            var modalElement = document.getElementById('modalInf');
            var modal = new bootstrap.Modal(modalElement);
            modal.show();
        }
    </script> -->
