<?php
require('fpdf.php');
include 'conexion.php';
if (isset($_GET['id'])) {
    $id = $_GET['id'];
}
// Clase extendida para definir header, footer y función NbLines
class PDF extends FPDF {
    // Calcula la cantidad de líneas que ocupará un MultiCell
    function NbLines($w, $txt) {
        $cw = &$this->CurrentFont['cw'];
        if($w == 0)
            $w = $this->w - $this->rMargin - $this->x;
        $wmax = ($w - 2 * $this->cMargin) * 1000 / $this->FontSize;
        $s = str_replace("\r", '', $txt);
        $nb = strlen($s);
        if($nb > 0 && $s[$nb-1] == "\n")
            $nb--;
        $sep = -1;
        $i = 0;
        $j = 0;
        $l = 0;
        $nl = 1;
        while($i < $nb) {
            $c = $s[$i];
            if($c == "\n") {
                $i++;
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
                continue;
            }
            if($c == ' ')
                $sep = $i;
            $l += $cw[$c];
            if($l > $wmax) {
                if($sep == -1) {
                    if($i == $j)
                        $i++;
                } else {
                    $i = $sep + 1;
                }
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
            } else {
                $i++;
            }
        }
        return $nl;
    }
    
    // Encabezado del documento
    function Header() {
        // Logo (ajusta la ruta y tamaño según necesites)
        $this->Image('images/logoradio2.jpg', 20, 10, 40);
        // Título del reporte
        $this->SetFont('Arial', 'B', 20);
        $this->SetTextColor(31, 73, 125); // Azul oscuro
        $this->Cell(0, 20, 'Detalle de Producto', 0, 1, 'C');
        // Línea divisoria
        $this->SetDrawColor(31, 73, 125);
        $this->SetLineWidth(0.5);
        $this->Line(10, 35, 200, 35);
        $this->Ln(10);
    }
    
    // Pie de página
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(128);
        $this->Cell(0, 10, 'Página ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}

// Crear PDF y configurar alias de páginas
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

// Consulta para obtener un único producto (el primero)
$sql = "SELECT * FROM inventariofull WHERE ID = $id";
$result = $conn->query($sql);

if (!$result) {
    die("Error en la consulta: " . $conn->error);
}

if ($row = $result->fetch_assoc()) {
    // Arreglo de campos a mostrar (ajusta nombres de columnas si es necesario)
    $fields = [
        "ID"                => $row['ID'],
        "Clasificación"     => $row['Clasificacion'],
        "Descripción"       => $row['Descripcion'],
        "Valor"             => "$" . number_format($row['Valor'], 2),
        "Resguardante"      => $row['Resguardante'],
        "Ubicación/Lote"    => $row['Ubicacion/Lote'],
        "Marca"             => $row['Marca'],
        "Modelo"            => $row['Modelo'],
        "Serie"             => $row['Serie'],
        "Origen"            => $row['Origen'],
        "Estatus"           => $row['Estatus'],
        "Vinculado"         => $row['Vinculado'],
        "Tipo"              => $row['Tipo']
    ];
    
    // Configuración de la tabla vertical
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->SetFillColor(210, 215, 229); // Fondo para las etiquetas
    $labelWidth = 50;   // Ancho de la columna de etiquetas
    $valueWidth = 130;  // Ancho de la columna de valores
    $lineHeight = 7;    // Altura base de línea
    
    foreach ($fields as $label => $value) {
        // Calcular la altura necesaria para el valor
        $nb = $pdf->NbLines($valueWidth, utf8_decode($value));
        $cellHeight = $lineHeight * $nb;
        // Guardar posición actual
        $x = $pdf->GetX();
        $y = $pdf->GetY();
        
        // Celda de etiqueta con fondo y texto en negrita
        $pdf->MultiCell($labelWidth, $cellHeight, utf8_decode($label), 1, 'L', true);
        // Posicionar la celda de valor a la derecha
        $pdf->SetXY($x + $labelWidth, $y);
        $pdf->SetFont('Arial', '', 12); // Valor en estilo normal
        $pdf->MultiCell($valueWidth, $lineHeight, utf8_decode($value), 1, 'L', false);
        // Regresar la fuente a negrita para la siguiente etiqueta
        $pdf->SetFont('Arial', 'B', 12);
    }
} else {
    $pdf->Cell(0, 10, 'No se encontró producto', 1, 1, 'C');
}

$conn->close();

// Limpiar el buffer y forzar la descarga del PDF
ob_clean();
$pdf->Output("D", "DetalleProducto.pdf");
exit();
?>